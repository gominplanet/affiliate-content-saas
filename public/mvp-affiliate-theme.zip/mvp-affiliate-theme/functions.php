<?php
/**
 * MVP Affiliate Theme — functions.php
 *
 * Theme setup, asset loading, customization data helper, and CSS variable
 * injection. The MVP Affiliate plugin manages all settings/data via the
 * affiliateos_customizations WordPress option; this theme reads from it.
 */

if (!defined('ABSPATH')) exit;

// Read the version straight from style.css's `Version:` header at runtime, so
// this constant can NEVER drift from the header again. A hardcoded number here
// had gone stale (constant said 1.4.32 while style.css said 1.4.33), which made
// the update banner compare 1.4.32 < 1.4.33 forever — clicking "Update" pulled a
// zip whose constant was still 1.4.32, so the banner came straight back. Same
// fix the plugin got on 2026-06-09 (get_file_data auto-read). The literal
// fallback is only used if the header can't be read for some reason.
if (!defined('MVP_AFFILIATE_THEME_VERSION')) {
    $mvp_theme_header = get_file_data(__DIR__ . '/style.css', ['Version' => 'Version']);
    define(
        'MVP_AFFILIATE_THEME_VERSION',
        !empty($mvp_theme_header['Version']) ? $mvp_theme_header['Version'] : '1.4.34'
    );
}

// ── Theme support ───────────────────────────────────────────────────────────
add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('responsive-embeds');
    add_theme_support('align-wide');
    add_theme_support('editor-styles');
    add_theme_support('html5', ['comment-list', 'comment-form', 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets']);
    add_theme_support('custom-logo', [
        'height'      => 80,
        'width'       => 240,
        'flex-width'  => true,
        'flex-height' => true,
    ]);

    register_nav_menus([
        'primary' => __('Primary Menu', 'mvp-affiliate'),
        'footer'  => __('Footer Menu',  'mvp-affiliate'),
    ]);

    // Custom image sizes for review cards
    add_image_size('mvp-card',       640,  360, true);  // 16:9
    add_image_size('mvp-card-large', 1200, 675, true); // hero
});

// ── Sidebar / widget area ───────────────────────────────────────────────────
add_action('widgets_init', function () {
    register_sidebar([
        'name'          => __('Post Sidebar', 'mvp-affiliate'),
        'id'            => 'sidebar-1',
        'description'   => 'Appears beside single review posts',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ]);
});

// ── Font theme map ──────────────────────────────────────────────────────────
// Keys must match the FONT_THEMES list in the dashboard's BrandPage.
function mvp_affiliate_font_theme_config(string $key): array {
    $map = [
        'editorial' => [
            'google' => '',
            'heading' => '"Charter", "Georgia", "Cambria", "Times New Roman", serif',
            'body'    => '-apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
        ],
        'modern' => [
            'google' => 'family=Inter:wght@400;500;600;700;800',
            'heading' => '"Inter", -apple-system, BlinkMacSystemFont, sans-serif',
            'body'    => '"Inter", -apple-system, BlinkMacSystemFont, sans-serif',
        ],
        'classic' => [
            'google' => 'family=Playfair+Display:wght@700;800&family=Lora:wght@400;500',
            'heading' => '"Playfair Display", Georgia, serif',
            'body'    => '"Lora", Georgia, "Times New Roman", serif',
        ],
        'bold' => [
            'google' => 'family=Space+Grotesk:wght@500;600;700&family=DM+Sans:wght@400;500;700',
            'heading' => '"Space Grotesk", -apple-system, BlinkMacSystemFont, sans-serif',
            'body'    => '"DM Sans", -apple-system, BlinkMacSystemFont, sans-serif',
        ],
        'minimal' => [
            'google' => '',
            'heading' => '-apple-system, BlinkMacSystemFont, "Helvetica Neue", Arial, sans-serif',
            'body'    => '-apple-system, BlinkMacSystemFont, "Helvetica Neue", Arial, sans-serif',
        ],
    ];
    return $map[$key] ?? $map['editorial'];
}

// ── Asset loading ───────────────────────────────────────────────────────────
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style(
        'mvp-affiliate-main',
        get_template_directory_uri() . '/assets/css/main.css',
        [],
        MVP_AFFILIATE_THEME_VERSION
    );
    wp_enqueue_script(
        'mvp-affiliate-main',
        get_template_directory_uri() . '/assets/js/main.js',
        [],
        MVP_AFFILIATE_THEME_VERSION,
        true
    );

    // Brand colors + font theme from saved customizations
    $data    = mvp_affiliate_data();
    $profile = $data['profile'] ?? [];
    $primary    = trim($profile['primaryColor'] ?? ($profile['accentColor'] ?? '#0071e3'));
    $secondary  = trim($profile['secondaryColor'] ?? '#34c759');
    $font_theme = trim($profile['fontTheme'] ?? 'editorial');
    $fonts = mvp_affiliate_font_theme_config($font_theme);

    // Optional user-set header/footer background colors. Empty = theme default.
    // When set, we auto-pick a readable text color from the background so the
    // header nav / footer links never end up invisible on the chosen color.
    $header_bg = trim($profile['headerBg'] ?? '');
    $footer_bg = trim($profile['footerBg'] ?? '');
    $chrome_css = '';
    if ($header_bg !== '') {
        $fg = mvp_affiliate_readable_fg($header_bg);
        $chrome_css .= sprintf(
            '--mvp-header-bg:%s;--mvp-header-fg:%s;--mvp-header-muted:color-mix(in srgb, %s 60%%, transparent);--mvp-header-border:color-mix(in srgb, %s 14%%, transparent);',
            esc_html($header_bg), $fg, $fg, $fg
        );
    }
    if ($footer_bg !== '') {
        $fg = mvp_affiliate_readable_fg($footer_bg);
        $chrome_css .= sprintf(
            '--mvp-footer-bg:%s;--mvp-footer-fg:%s;--mvp-footer-muted:color-mix(in srgb, %s 58%%, transparent);--mvp-footer-faint:color-mix(in srgb, %s 42%%, transparent);--mvp-footer-border:color-mix(in srgb, %s 10%%, transparent);',
            esc_html($footer_bg), $fg, $fg, $fg, $fg
        );
    }

    // Google Fonts (if needed) — load BEFORE main.css so font-family is available
    if (!empty($fonts['google'])) {
        wp_enqueue_style(
            'mvp-affiliate-fonts',
            'https://fonts.googleapis.com/css2?' . $fonts['google'] . '&display=swap',
            [],
            null
        );
    }

    // Inline CSS variable overrides
    $css = sprintf(
        ':root {--mvp-primary:%s;--mvp-secondary:%s;--mvp-font-serif:%s;--mvp-font-sans:%s;%s}',
        esc_html($primary),
        esc_html($secondary),
        $fonts['heading'],
        $fonts['body'],
        $chrome_css
    );
    wp_add_inline_style('mvp-affiliate-main', $css);
});

// Pick a readable text color (near-black or white) for a given background hex,
// based on its relative luminance. Keeps header nav / footer links legible
// whatever background the creator chooses. Falls back to white on a bad value.
if (!function_exists('mvp_affiliate_readable_fg')) {
    function mvp_affiliate_readable_fg(string $hex, string $light = '#ffffff', string $dark = '#1a1a1e'): string {
        $hex = ltrim(trim($hex), '#');
        if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
        if (strlen($hex) !== 6 || !ctype_xdigit($hex)) return $light;
        $lin = function ($c) { $c /= 255; return $c <= 0.03928 ? $c / 12.92 : pow(($c + 0.055) / 1.055, 2.4); };
        $L = 0.2126 * $lin(hexdec(substr($hex, 0, 2)))
           + 0.7152 * $lin(hexdec(substr($hex, 2, 2)))
           + 0.0722 * $lin(hexdec(substr($hex, 4, 2)));
        return $L > 0.42 ? $dark : $light;
    }
}

// ── Customizations data helper ─────────────────────────────────────────────
// Returns the affiliateos_customizations option as a normalized array.
if (!function_exists('mvp_affiliate_data')) {
    function mvp_affiliate_data(): array {
        static $cache = null;
        if ($cache === null) {
            $raw = get_option('affiliateos_customizations', []);
            $cache = is_array($raw) ? $raw : [];
        }
        return $cache;
    }
}

// ── Tell the plugin we're rendering — so it can skip its own renderers ─────
add_filter('mvp_affiliate_theme_active', '__return_true');

// ── Helpers (shortcut accessors) ────────────────────────────────────────────
require_once get_template_directory() . '/inc/template-tags.php';
require_once get_template_directory() . '/inc/customizations.php';

// ── Excerpt tweaks ──────────────────────────────────────────────────────────
add_filter('excerpt_length', function () { return 28; });
add_filter('excerpt_more',   function () { return '…'; });

// ── Custom <head> meta tags (site verification, etc.) ───────────────────────
// The site runs this theme (not Kadence + plugin), so the plugin's head
// injection never fires here — the theme has to do it. Users paste
// verification tags (Google Search Console, Pinterest, Facebook, Impact,
// Bing…) in the dashboard. Sanitize HARD with wp_kses: only a bare <meta>
// with a fixed inert-attribute whitelist survives.
add_action('wp_head', function () {
    $tags = mvp_affiliate_data()['headMetaTags'] ?? [];
    if (!is_array($tags) || empty($tags)) return;

    $allowed = [
        'meta' => [
            'name'       => true,
            'property'   => true,
            'http-equiv' => true,
            'content'    => true,
            'value'      => true,   // Impact uses value= instead of content=
            'itemprop'   => true,
            'charset'    => true,
        ],
    ];

    echo "\n<!-- MVP Affiliate: custom meta -->\n";
    foreach ($tags as $raw) {
        if (!is_string($raw)) continue;
        $clean = trim(wp_kses($raw, $allowed));
        if ($clean !== '' && stripos($clean, '<meta') === 0) {
            echo $clean . "\n";
        }
    }
}, 1);

// ── Serve /ads.txt from the saved AdSense publisher ID ──────────────────────
// AdSense wants an ads.txt at the domain root authorizing your publisher
// account. We serve it dynamically from the dashboard-saved ca-pub ID so the
// user never touches files. Only fires when WP actually handles /ads.txt —
// a real ads.txt on disk is served by the web server first and left untouched.
add_action('init', function () {
    $path = isset($_SERVER['REQUEST_URI']) ? (string) wp_parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) : '';
    if (strtolower(rtrim($path, '/')) !== '/ads.txt') return;
    $id = '';
    if (function_exists('mvp_affiliate_data')) {
        $raw = trim(mvp_affiliate_data()['adsenseClientId'] ?? '');
        if (preg_match('/^ca-pub-(\d{10,20})$/', $raw, $m)) $id = $m[1];
    }
    if ($id === '') return; // no AdSense configured → let WP handle the URL normally
    header('Content-Type: text/plain; charset=utf-8');
    // Google's standard AdSense ads.txt line (f08c… is Google's certification ID).
    echo "google.com, pub-{$id}, DIRECT, f08c47fec0942fa0\n";
    exit;
});

// ── Self-update: native "Update available" in wp-admin ──────────────────────
// Polls https://www.mvpaffiliate.io/api/wp-version (cached 6h) and, if a
// newer theme version is published, injects an entry into WP's theme-update
// transient. The user then sees the normal Appearance → Themes "update now"
// button — one click, no delete-and-reinstall.
//
// The remote-version fetch is shared with the plugin (if both are installed)
// via a function_exists guard.
if (!function_exists('mvp_affiliate_fetch_remote_version')) {
    function mvp_affiliate_fetch_remote_version() {
        $cached = get_transient('mvp_affiliate_remote_version');
        if ($cached !== false) return $cached;
        $res = wp_remote_get('https://www.mvpaffiliate.io/api/wp-version', [
            'timeout' => 8,
            'headers' => ['Accept' => 'application/json'],
        ]);
        if (is_wp_error($res) || (int) wp_remote_retrieve_response_code($res) !== 200) {
            // Cache the failure briefly so a flaky network doesn't hammer the
            // endpoint on every admin page load.
            set_transient('mvp_affiliate_remote_version', null, 30 * MINUTE_IN_SECONDS);
            return null;
        }
        $data = json_decode(wp_remote_retrieve_body($res), true);
        if (!is_array($data)) return null;
        set_transient('mvp_affiliate_remote_version', $data, 6 * HOUR_IN_SECONDS);
        return $data;
    }
}

add_filter('pre_set_site_transient_update_themes', function ($transient) {
    if (!is_object($transient)) return $transient;
    $info = mvp_affiliate_fetch_remote_version();
    if (empty($info['theme']['version'])) return $transient;

    $slug    = 'mvp-affiliate-theme';
    $latest  = (string) $info['theme']['version'];
    $package = (string) ($info['theme']['download_url'] ?? '');

    if ($package && version_compare(MVP_AFFILIATE_THEME_VERSION, $latest, '<')) {
        $transient->response[$slug] = [
            'theme'       => $slug,
            'new_version' => $latest,
            'url'         => 'https://www.mvpaffiliate.io',
            'package'     => $package,
        ];
    } else {
        // Not stale — make sure WP doesn't keep a phantom update queued.
        unset($transient->response[$slug]);
    }
    return $transient;
});

// ── Prominent "update available" banner ─────────────────────────────────────
// WordPress's native theme-update hint is a tiny line of text buried on the
// Appearance → Themes screen — easy to miss. This shows a bold RED banner at
// the top of EVERY wp-admin page whenever a newer theme version is published,
// with a one-click "Update now" button. It only renders for users who can
// actually update themes, and disappears automatically once they're current.
add_action('admin_notices', function () {
    if (!current_user_can('update_themes')) return;
    $info = mvp_affiliate_fetch_remote_version();
    if (empty($info['theme']['version'])) return;
    $latest = (string) $info['theme']['version'];
    if (!version_compare(MVP_AFFILIATE_THEME_VERSION, $latest, '<')) return;

    $slug       = 'mvp-affiliate-theme';
    $update_url = wp_nonce_url(
        self_admin_url('update.php?action=upgrade-theme&theme=' . $slug),
        'upgrade-theme_' . $slug
    );
    ?>
    <div class="notice notice-error" style="border-left-width:6px;border-left-color:#d63638;background:#fcf0f1;padding:16px 18px;">
      <p style="font-size:15px;margin:0 0 10px;color:#1d2327;">
        <span style="display:inline-block;font-weight:700;color:#d63638;">⚠ MVP Affiliate theme update available — v<?php echo esc_html($latest); ?></span>
        <span style="opacity:.85;"> (you're on v<?php echo esc_html(MVP_AFFILIATE_THEME_VERSION); ?>). Update now to get the latest fixes and features.</span>
      </p>
      <p style="margin:0;">
        <a href="<?php echo esc_url($update_url); ?>" class="button button-primary" style="background:#d63638;border-color:#d63638;box-shadow:none;text-shadow:none;font-weight:600;">
          Update theme now
        </a>
        <a href="<?php echo esc_url(self_admin_url('themes.php')); ?>" style="margin-left:10px;color:#d63638;">View in Appearance → Themes</a>
      </p>
    </div>
    <?php
});

// ── Comments (used in templates) ────────────────────────────────────────────
add_action('after_setup_theme', function () {
    add_theme_support('comment-list');
});
