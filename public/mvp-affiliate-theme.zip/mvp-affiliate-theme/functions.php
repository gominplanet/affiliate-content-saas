<?php
/**
 * MVP Affiliate Theme — functions.php
 *
 * Theme setup, asset loading, customization data helper, and CSS variable
 * injection. The MVP Affiliate plugin manages all settings/data via the
 * affiliateos_customizations WordPress option; this theme reads from it.
 */

if (!defined('ABSPATH')) exit;

define('MVP_AFFILIATE_THEME_VERSION', '1.4.10');

// ── Theme support ───────────────────────────────────────────────────────────
add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('responsive-embeds');
    add_theme_support('align-wide');
    add_theme_support('editor-styles');
    add_theme_support('html5', ['comment-list', 'comment-form', 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets']);
    add_theme_support('custom-logo', [
        'height'      => 80,
        'width'       => 240,
        'flex-width'  => true,
        'flex-height' => true,
    ]);

    register_nav_menus([
        'primary' => __('Primary Menu', 'mvp-affiliate'),
        'footer'  => __('Footer Menu',  'mvp-affiliate'),
    ]);

    // Custom image sizes for review cards
    add_image_size('mvp-card',       640,  360, true);  // 16:9
    add_image_size('mvp-card-large', 1200, 675, true); // hero
});

// ── Sidebar / widget area ───────────────────────────────────────────────────
add_action('widgets_init', function () {
    register_sidebar([
        'name'          => __('Post Sidebar', 'mvp-affiliate'),
        'id'            => 'sidebar-1',
        'description'   => 'Appears beside single review posts',
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ]);
});

// ── Font theme map ──────────────────────────────────────────────────────────
// Keys must match the FONT_THEMES list in the dashboard's BrandPage.
function mvp_affiliate_font_theme_config(string $key): array {
    $map = [
        'editorial' => [
            'google' => '',
            'heading' => '"Charter", "Georgia", "Cambria", "Times New Roman", serif',
            'body'    => '-apple-system, BlinkMacSystemFont, "Inter", "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
        ],
        'modern' => [
            'google' => 'family=Inter:wght@400;500;600;700;800',
            'heading' => '"Inter", -apple-system, BlinkMacSystemFont, sans-serif',
            'body'    => '"Inter", -apple-system, BlinkMacSystemFont, sans-serif',
        ],
        'classic' => [
            'google' => 'family=Playfair+Display:wght@700;800&family=Lora:wght@400;500',
            'heading' => '"Playfair Display", Georgia, serif',
            'body'    => '"Lora", Georgia, "Times New Roman", serif',
        ],
        'bold' => [
            'google' => 'family=Space+Grotesk:wght@500;600;700&family=DM+Sans:wght@400;500;700',
            'heading' => '"Space Grotesk", -apple-system, BlinkMacSystemFont, sans-serif',
            'body'    => '"DM Sans", -apple-system, BlinkMacSystemFont, sans-serif',
        ],
        'minimal' => [
            'google' => '',
            'heading' => '-apple-system, BlinkMacSystemFont, "Helvetica Neue", Arial, sans-serif',
            'body'    => '-apple-system, BlinkMacSystemFont, "Helvetica Neue", Arial, sans-serif',
        ],
    ];
    return $map[$key] ?? $map['editorial'];
}

// ── Asset loading ───────────────────────────────────────────────────────────
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style(
        'mvp-affiliate-main',
        get_template_directory_uri() . '/assets/css/main.css',
        [],
        MVP_AFFILIATE_THEME_VERSION
    );
    wp_enqueue_script(
        'mvp-affiliate-main',
        get_template_directory_uri() . '/assets/js/main.js',
        [],
        MVP_AFFILIATE_THEME_VERSION,
        true
    );

    // Brand colors + font theme from saved customizations
    $data    = mvp_affiliate_data();
    $profile = $data['profile'] ?? [];
    $primary    = trim($profile['primaryColor'] ?? ($profile['accentColor'] ?? '#0071e3'));
    $secondary  = trim($profile['secondaryColor'] ?? '#34c759');
    $font_theme = trim($profile['fontTheme'] ?? 'editorial');
    $fonts = mvp_affiliate_font_theme_config($font_theme);

    // Google Fonts (if needed) — load BEFORE main.css so font-family is available
    if (!empty($fonts['google'])) {
        wp_enqueue_style(
            'mvp-affiliate-fonts',
            'https://fonts.googleapis.com/css2?' . $fonts['google'] . '&display=swap',
            [],
            null
        );
    }

    // Inline CSS variable overrides
    $css = sprintf(
        ':root {--mvp-primary:%s;--mvp-secondary:%s;--mvp-font-serif:%s;--mvp-font-sans:%s;}',
        esc_html($primary),
        esc_html($secondary),
        $fonts['heading'],
        $fonts['body']
    );
    wp_add_inline_style('mvp-affiliate-main', $css);
});

// ── Customizations data helper ─────────────────────────────────────────────
// Returns the affiliateos_customizations option as a normalized array.
if (!function_exists('mvp_affiliate_data')) {
    function mvp_affiliate_data(): array {
        static $cache = null;
        if ($cache === null) {
            $raw = get_option('affiliateos_customizations', []);
            $cache = is_array($raw) ? $raw : [];
        }
        return $cache;
    }
}

// ── Tell the plugin we're rendering — so it can skip its own renderers ─────
add_filter('mvp_affiliate_theme_active', '__return_true');

// ── Helpers (shortcut accessors) ────────────────────────────────────────────
require_once get_template_directory() . '/inc/template-tags.php';
require_once get_template_directory() . '/inc/customizations.php';

// ── Excerpt tweaks ──────────────────────────────────────────────────────────
add_filter('excerpt_length', function () { return 28; });
add_filter('excerpt_more',   function () { return '…'; });

// ── Custom <head> meta tags (site verification, etc.) ───────────────────────
// The site runs this theme (not Kadence + plugin), so the plugin's head
// injection never fires here — the theme has to do it. Users paste
// verification tags (Google Search Console, Pinterest, Facebook, Impact,
// Bing…) in the dashboard. Sanitize HARD with wp_kses: only a bare <meta>
// with a fixed inert-attribute whitelist survives.
add_action('wp_head', function () {
    $tags = mvp_affiliate_data()['headMetaTags'] ?? [];
    if (!is_array($tags) || empty($tags)) return;

    $allowed = [
        'meta' => [
            'name'       => true,
            'property'   => true,
            'http-equiv' => true,
            'content'    => true,
            'value'      => true,   // Impact uses value= instead of content=
            'itemprop'   => true,
            'charset'    => true,
        ],
    ];

    echo "\n<!-- MVP Affiliate: custom meta -->\n";
    foreach ($tags as $raw) {
        if (!is_string($raw)) continue;
        $clean = trim(wp_kses($raw, $allowed));
        if ($clean !== '' && stripos($clean, '<meta') === 0) {
            echo $clean . "\n";
        }
    }
}, 1);

// ── Self-update: native "Update available" in wp-admin ──────────────────────
// Polls https://www.mvpaffiliate.io/api/wp-version (cached 6h) and, if a
// newer theme version is published, injects an entry into WP's theme-update
// transient. The user then sees the normal Appearance → Themes "update now"
// button — one click, no delete-and-reinstall.
//
// The remote-version fetch is shared with the plugin (if both are installed)
// via a function_exists guard.
if (!function_exists('mvp_affiliate_fetch_remote_version')) {
    function mvp_affiliate_fetch_remote_version() {
        $cached = get_transient('mvp_affiliate_remote_version');
        if ($cached !== false) return $cached;
        $res = wp_remote_get('https://www.mvpaffiliate.io/api/wp-version', [
            'timeout' => 8,
            'headers' => ['Accept' => 'application/json'],
        ]);
        if (is_wp_error($res) || (int) wp_remote_retrieve_response_code($res) !== 200) {
            // Cache the failure briefly so a flaky network doesn't hammer the
            // endpoint on every admin page load.
            set_transient('mvp_affiliate_remote_version', null, 30 * MINUTE_IN_SECONDS);
            return null;
        }
        $data = json_decode(wp_remote_retrieve_body($res), true);
        if (!is_array($data)) return null;
        set_transient('mvp_affiliate_remote_version', $data, 6 * HOUR_IN_SECONDS);
        return $data;
    }
}

add_filter('pre_set_site_transient_update_themes', function ($transient) {
    if (!is_object($transient)) return $transient;
    $info = mvp_affiliate_fetch_remote_version();
    if (empty($info['theme']['version'])) return $transient;

    $slug    = 'mvp-affiliate-theme';
    $latest  = (string) $info['theme']['version'];
    $package = (string) ($info['theme']['download_url'] ?? '');

    if ($package && version_compare(MVP_AFFILIATE_THEME_VERSION, $latest, '<')) {
        $transient->response[$slug] = [
            'theme'       => $slug,
            'new_version' => $latest,
            'url'         => 'https://www.mvpaffiliate.io',
            'package'     => $package,
        ];
    } else {
        // Not stale — make sure WP doesn't keep a phantom update queued.
        unset($transient->response[$slug]);
    }
    return $transient;
});

// ── Prominent "update available" banner ─────────────────────────────────────
// WordPress's native theme-update hint is a tiny line of text buried on the
// Appearance → Themes screen — easy to miss. This shows a bold RED banner at
// the top of EVERY wp-admin page whenever a newer theme version is published,
// with a one-click "Update now" button. It only renders for users who can
// actually update themes, and disappears automatically once they're current.
add_action('admin_notices', function () {
    if (!current_user_can('update_themes')) return;
    $info = mvp_affiliate_fetch_remote_version();
    if (empty($info['theme']['version'])) return;
    $latest = (string) $info['theme']['version'];
    if (!version_compare(MVP_AFFILIATE_THEME_VERSION, $latest, '<')) return;

    $slug       = 'mvp-affiliate-theme';
    $update_url = wp_nonce_url(
        self_admin_url('update.php?action=upgrade-theme&theme=' . $slug),
        'upgrade-theme_' . $slug
    );
    ?>
    <div class="notice notice-error" style="border-left-width:6px;border-left-color:#d63638;background:#fcf0f1;padding:16px 18px;">
      <p style="font-size:15px;margin:0 0 10px;color:#1d2327;">
        <span style="display:inline-block;font-weight:700;color:#d63638;">⚠ MVP Affiliate theme update available — v<?php echo esc_html($latest); ?></span>
        <span style="opacity:.85;"> (you're on v<?php echo esc_html(MVP_AFFILIATE_THEME_VERSION); ?>). Update now to get the latest fixes and features.</span>
      </p>
      <p style="margin:0;">
        <a href="<?php echo esc_url($update_url); ?>" class="button button-primary" style="background:#d63638;border-color:#d63638;box-shadow:none;text-shadow:none;font-weight:600;">
          Update theme now
        </a>
        <a href="<?php echo esc_url(self_admin_url('themes.php')); ?>" style="margin-left:10px;color:#d63638;">View in Appearance → Themes</a>
      </p>
    </div>
    <?php
});

// ── Comments (used in templates) ────────────────────────────────────────────
add_action('after_setup_theme', function () {
    add_theme_support('comment-list');
});
