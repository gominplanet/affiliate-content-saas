<?php if (!defined('ABSPATH')) exit;
// Google Tag Manager — strict format validation. Anything else is
// dropped silently rather than injected, so a malformed paste can't
// produce broken <script> output on every blog page.
$mvp_gtm_id = '';
$mvp_ga4_id = '';
if (function_exists('mvp_affiliate_data')) {
    $mvp_d = mvp_affiliate_data();
    $mvp_candidate = trim($mvp_d['analytics']['gtmId'] ?? '');
    if (preg_match('/^GTM-[A-Z0-9]{4,12}$/', $mvp_candidate)) {
        $mvp_gtm_id = $mvp_candidate;
    }
    // Direct GA4 (gtag.js) — the simple path: paste a G-XXXXXXXX Measurement
    // ID, no GTM container required. Same strict-validate-or-drop approach.
    $mvp_ga4_candidate = trim($mvp_d['analytics']['ga4Id'] ?? '');
    if (preg_match('/^G-[A-Z0-9]{4,12}$/', $mvp_ga4_candidate)) {
        $mvp_ga4_id = $mvp_ga4_candidate;
    }
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <link rel="profile" href="https://gmpg.org/xfn/11" />
  <?php if ($mvp_gtm_id): ?>
  <!-- Google Tag Manager -->
  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
  new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
  j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
  'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
  })(window,document,'script','dataLayer','<?php echo esc_js($mvp_gtm_id); ?>');</script>
  <!-- End Google Tag Manager -->
  <?php endif; ?>
  <?php if ($mvp_ga4_id): ?>
  <!-- Google tag (gtag.js) — direct GA4, no GTM needed -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo esc_attr($mvp_ga4_id); ?>"></script>
  <script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', '<?php echo esc_js($mvp_ga4_id); ?>');
  </script>
  <!-- End Google tag (gtag.js) -->
  <?php endif; ?>
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<?php if ($mvp_gtm_id): ?>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo esc_attr($mvp_gtm_id); ?>"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<?php endif; ?>

<?php
$about    = mvp_affiliate_about();
$profile  = mvp_affiliate_profile();
$logo_url = $about['logoUrl'] ?? '';
// Optional wide top banner. When set, replaces the small centered logo
// so creators can run a real header image (recommended 1920x240).
$banner_url = trim($about['headerBannerUrl'] ?? '');
$top_img    = $banner_url !== '' ? $banner_url : $logo_url;
$is_banner  = $banner_url !== '';
$bg       = ($about['headerBg'] ?? 'black') === 'white' ? '#ffffff' : '#000000';
$brand    = get_bloginfo('name');
$socials  = mvp_affiliate_socials();
$disclaimer = trim($profile['affiliateDisclaimer'] ?? '');
if ($disclaimer === '') {
    $disclaimer = 'This site contains affiliate links. We may earn a commission on purchases made through links on this site, at no extra cost to you.';
}
?>

<!-- Utility bar: socials only. The affiliate disclaimer is NOT shown here —
     it lived in this slim strip and got crushed to one-word-per-line on mobile,
     wrecking the layout. The disclaimer still appears in-article (the highlighted
     box under the title) and in the footer, which is where readers expect it and
     where Amazon's policy is satisfied. The bar only renders when there are
     social links, so it's never an empty black strip. -->
<?php if (!empty($socials)): ?>
<div class="mvp-utilitybar">
  <div class="mvp-container mvp-utilitybar-inner">
    <div class="mvp-utilitybar-socials">
      <?php foreach ($socials as $key => $url):
        $svg = mvp_affiliate_social_svg($key);
        if (!$svg) continue;
        $href = ($key === 'contact') ? 'mailto:' . antispambot($url) : esc_url($url);
        $target = ($key === 'contact') ? '_self' : '_blank';
      ?>
      <a href="<?php echo $href; ?>" target="<?php echo $target; ?>" rel="noopener" aria-label="<?php echo esc_attr(ucfirst($key)); ?>" class="mvp-utilitybar-social">
        <?php echo $svg; ?>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Logo banner (small centered logo, or full wide banner if uploaded) -->
<?php if ($top_img): ?>
<div class="mvp-logobanner<?php echo $is_banner ? ' mvp-logobanner--banner' : ''; ?>" style="background:<?php echo $bg; ?>;">
  <a href="<?php echo esc_url(home_url('/')); ?>" class="mvp-logobanner-link" aria-label="<?php echo esc_attr($brand); ?>">
    <img src="<?php echo esc_url($top_img); ?>" alt="<?php echo esc_attr($brand); ?>" class="mvp-logobanner-img<?php echo $is_banner ? ' mvp-logobanner-img--banner' : ''; ?>" />
  </a>
</div>
<?php endif; ?>

<!-- Main header -->
<header class="mvp-header">
  <div class="mvp-container mvp-header-inner">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="mvp-header-brand">
      <span class="mvp-header-title"><?php echo esc_html($brand); ?></span>
      <?php $tagline = get_bloginfo('description'); if ($tagline): ?>
      <span class="mvp-header-tagline"><?php echo esc_html($tagline); ?></span>
      <?php endif; ?>
    </a>

    <nav class="mvp-header-nav" aria-label="<?php esc_attr_e('Primary', 'mvp-affiliate'); ?>">
      <?php
      // ALWAYS build the nav from the site's own content: "All Reviews"
      // (home) → the category hubs → "About". We deliberately ignore any
      // assigned 'primary' WP menu, because leftover/sample menus from a
      // previous theme (e.g. "Blog / Review Videos / Contact") would
      // otherwise hijack the header. This keeps every MVP site's nav
      // consistent — review categories, nothing stray.
      echo '<ul class="mvp-nav-menu">';
      echo '<li class="menu-item"><a href="' . esc_url(home_url('/')) . '">' . esc_html__('All Reviews', 'mvp-affiliate') . '</a></li>';
      wp_list_categories([
          'title_li'   => '',
          'orderby'    => 'count',
          'order'      => 'DESC',
          'number'     => 7,
          'hide_empty' => true,
      ]);
      $mvp_about = get_page_by_path('about');
      if ($mvp_about) {
          echo '<li class="menu-item"><a href="' . esc_url(get_permalink($mvp_about)) . '">' . esc_html__('About', 'mvp-affiliate') . '</a></li>';
      }
      echo '</ul>';
      ?>
    </nav>

    <button class="mvp-header-search-toggle" aria-label="<?php esc_attr_e('Toggle search', 'mvp-affiliate'); ?>" type="button" data-mvp-search-toggle>
      <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m21 21-3.5-3.5"/></svg>
    </button>

    <button class="mvp-header-menu-toggle" aria-label="<?php esc_attr_e('Toggle menu', 'mvp-affiliate'); ?>" type="button" data-mvp-menu-toggle>
      <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
    </button>
  </div>

  <!-- Search drawer -->
  <div class="mvp-header-search" data-mvp-search hidden>
    <div class="mvp-container">
      <?php get_search_form(); ?>
    </div>
  </div>
</header>
