<?php if (!defined('ABSPATH')) exit;
get_header();
?>

<main class="mvp-main mvp-single">
  <div class="mvp-container mvp-single-layout">

    <article class="mvp-single-content">
      <?php while (have_posts()): the_post(); ?>

      <header class="mvp-single-header">
        <?php echo mvp_affiliate_category_badge(); ?>
        <h1 class="mvp-single-title"><?php the_title(); ?></h1>
        <?php if (has_excerpt()): ?>
        <p class="mvp-single-dek"><?php echo esc_html(get_the_excerpt()); ?></p>
        <?php endif; ?>
        <div class="mvp-single-meta">
          <?php mvp_affiliate_posted_meta(); ?>
        </div>
      </header>

      <?php /*
        Featured-image block intentionally NOT rendered on single posts.
        The thumbnail is still stored on the WP post and shown everywhere
        else (homepage hero/featured grid, category archives, "Latest
        Reviews" grid, "Browse by Category"). Reason: every review has a
        YouTube "Watch Our Review" embed immediately below this point
        whose poster image is the same thumbnail — rendering both would
        show the same image twice in a row.
      */ ?>

      <div class="mvp-single-body">
        <?php the_content(); ?>
      </div>

      <?php
      // Tags
      $tags = get_the_tags();
      if ($tags): ?>
      <div class="mvp-single-tags">
        <?php foreach ($tags as $tag): ?>
        <a href="<?php echo esc_url(get_tag_link($tag->term_id)); ?>" class="mvp-tag">#<?php echo esc_html($tag->name); ?></a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <?php endwhile; ?>

      <?php /* ─── MOBILE-ONLY sticky "Buy" bar ────────────────────────────
            Sits fixed at the bottom of the viewport on screens < 768px so
            mobile readers always have the affiliate CTA in reach — they
            don't need to scroll back to the verdict to find one. We pull
            the first affiliate-link out of the post content (amazon /
            geni.us / amzn.to / a.co); falls back to invisible if nothing
            matches. The bar is CSS-hidden on desktop. */ ?>
      <?php
      $buy_url = mvp_affiliate_extract_affiliate_link(get_the_content());
      if ($buy_url):
      ?>
      <div class="mvp-mobile-buy-bar" role="complementary" aria-label="Buy this product">
        <a href="<?php echo esc_url($buy_url); ?>" target="_blank" rel="noopener sponsored nofollow" class="mvp-mobile-buy-btn">
          Check the price →
        </a>
      </div>
      <?php endif; ?>

      <?php
      // Comment section — only when the creator switched comments ON in
      // Customize Blog. mvp_affiliate_comments_enabled() also forces
      // comments_open() true (via a filter) so the form shows on posts that
      // WordPress created with comments closed, with no per-post fiddling.
      if (mvp_affiliate_comments_enabled()) {
          comments_template();
      }
      ?>
    </article>

    <aside class="mvp-single-sidebar">
      <?php
      // 0. Newsletter — TOP slot. Renders before everything else when the
      //    creator picks "Top of sidebar" on the dashboard.
      echo mvp_affiliate_render_newsletter_at('sidebar', 'top');

      // 1. Pick of the Day
      echo mvp_affiliate_render_pick_of_day('sidebar');

      // 2. Render dynamic sidebar widgets (registered in functions.php)
      if (is_active_sidebar('sidebar-1')) {
          dynamic_sidebar('sidebar-1');
      }

      // 3. Render MVP Affiliate sidebar ad blocks. Enabled banners are all output;
      //    the browser shuffles (rotate) and caps (show N) on each load so it works
      //    under full-page caching. No-JS fallback: all enabled banners show in order.
      $side_blocks = mvp_affiliate_sidebar_blocks_display();
      if (!empty($side_blocks)) {
          // Render each enabled block first and DROP the empties (image block
          // with no imageUrl, html block with no html). If we wrapped those in
          // .mvp-sidebar-ad-item anyway they'd occupy shuffle/cap slots — which
          // is why "show 3" sometimes showed 1: two of the slots were blank.
          $side_html = array();
          foreach ($side_blocks as $block) {
              $b = mvp_affiliate_render_block($block);
              if (trim($b) !== '') {
                  $side_html[] = $b;
              }
          }
      }
      if (!empty($side_html)) {
          $side_rotate = mvp_affiliate_sidebar_rotate() ? '1' : '0';
          $side_show   = mvp_affiliate_sidebar_show_count();
          echo '<div class="mvp-sidebar-ads" data-rotate="' . esc_attr($side_rotate) . '" data-show="' . esc_attr((string) $side_show) . '">';
          foreach ($side_html as $b) {
              echo '<div class="mvp-sidebar-ad-item">' . $b . '</div>';
          }
          echo '</div>';
          if ($side_rotate === '1' || $side_show > 0) {
              ?>
              <script>
              (function(){
                var box = document.querySelector('.mvp-sidebar-ads');
                if (!box) return;
                var items = [].slice.call(box.children);
                if (box.getAttribute('data-rotate') === '1') {
                  for (var i = items.length - 1; i > 0; i--) {
                    var j = Math.floor(Math.random() * (i + 1));
                    var t = items[i]; items[i] = items[j]; items[j] = t;
                  }
                  items.forEach(function (el) { box.appendChild(el); });
                }
                var show = parseInt(box.getAttribute('data-show'), 10) || 0;
                if (show > 0) {
                  [].slice.call(box.children).forEach(function (el, idx) {
                    if (idx >= show) el.style.display = 'none';
                  });
                }
              })();
              </script>
              <?php
          }
      }

      // 4. Newsletter — BOTTOM slot (default). Renders after everything
      //    else when the creator picks "After other ads" (or hasn't
      //    chosen a slot at all). Silent no-op when newsletter is off.
      echo mvp_affiliate_render_newsletter_at('sidebar', 'bottom');
      ?>
    </aside>

  </div>

  <!-- You Might Also Like -->
  <?php
  $related = new WP_Query([
      'post_type'           => 'post',
      'post_status'         => 'publish',
      'posts_per_page'      => 4,
      'orderby'             => 'rand',
      'post__not_in'        => [get_the_ID()],
      'ignore_sticky_posts' => 1,
  ]);
  if ($related->have_posts()):
  ?>
  <section class="mvp-section mvp-section-related">
    <div class="mvp-container">
      <header class="mvp-section-header">
        <h2 class="mvp-section-title">You might also like</h2>
      </header>
      <div class="mvp-grid mvp-grid-4">
        <?php while ($related->have_posts()): $related->the_post(); ?>
        <article class="mvp-card">
          <a href="<?php the_permalink(); ?>" class="mvp-card-link">
            <?php if (has_post_thumbnail()): ?>
            <div class="mvp-card-image">
              <?php the_post_thumbnail('mvp-card', ['loading' => 'lazy']); ?>
            </div>
            <?php endif; ?>
            <div class="mvp-card-body">
              <?php echo mvp_affiliate_category_badge(); ?>
              <h3 class="mvp-card-title"><?php the_title(); ?></h3>
            </div>
          </a>
        </article>
        <?php endwhile; wp_reset_postdata(); ?>
      </div>
    </div>
  </section>
  <?php endif; ?>

</main>

<?php get_footer();
