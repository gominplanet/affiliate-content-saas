=== MVP Affiliate ===
Contributors: mvpaffiliate
Tags: blog, editorial, affiliate, custom-colors, featured-images, threaded-comments
Requires at least: 5.6
Tested up to: 6.7
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later

Editorial affiliate review theme designed for MVP Affiliate. Wirecutter-
inspired typography and Tom's Guide content density, with a clean review-
post layout and prominent product callouts.

== Description ==

MVP Affiliate is the official theme for the MVP Affiliate dashboard.
It pairs with the MVP Affiliate plugin to render a polished affiliate
review website without any manual editing.

Features:

* Editorial homepage with hero card and review grid
* Single-post layout with sidebar and ad blocks
* "Our Pick" callout box for hero product recommendations
* Built-in affiliate disclaimer block in the footer
* Brand colors driven by your MVP Affiliate dashboard
* Mobile-first responsive layout
* Block editor (Gutenberg) ready

== Installation ==

1. Activate the MVP Affiliate plugin first
2. Upload this theme zip via Appearance → Themes → Add New → Upload Theme
3. Activate

The theme reads all settings (brand name, tagline, bio, socials, ad
blocks, etc.) from the MVP Affiliate plugin's data store. Manage
everything from your MVP Affiliate dashboard.

== Changelog ==

= 1.4.32 =
* Header & footer background colors are now customizable from the dashboard
  Brand page. Text and icons auto-adjust for readability on any chosen color.

= 1.4.31 =
* Softer footer + About band background (charcoal instead of near-black) for a
  gentler, less harsh look.

= 1.4.30 =
* Cleaner, more compact footer: brand column with logo + tagline + socials,
  categories in a balanced 2-column grid (deduped + capped), links column only
  when it has content, and a slim single-row bottom bar (copyright + disclosure).

= 1.0.0 =
* Initial release
