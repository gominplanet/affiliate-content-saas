<?php
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('kadence-child-style', get_stylesheet_uri(), ['kadence-global'], '1.0.0');
});

// Ensure 9 categories max per page in category taxonomy
add_filter('widget_tag_cloud_args', function ($args) {
    $args['number'] = 9;
    return $args;
});

// Register custom AffiliateOS options so they're readable/writable via WP REST API
add_action('init', function () {
    $opts = [
        'affiliateos_accent_color',
        'affiliateos_about_text',
        'affiliateos_author_name',
        'affiliateos_author_img',
        'affiliateos_youtube_url',
        'affiliateos_instagram_url',
        'affiliateos_tiktok_url',
        'affiliateos_twitter_url',
        'affiliateos_pinterest_url',
        'affiliateos_facebook_url',
        'affiliateos_contact_email',
        'affiliateos_disclaimer',
    ];
    foreach ($opts as $opt) {
        register_setting('general', $opt, [
            'type'         => 'string',
            'show_in_rest' => true,
            'default'      => '',
        ]);
    }
});
